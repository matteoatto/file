export class Dipendente {
  id!: number;
  name!: string;
  surname!: string;
  date!: string;
  salary!: number;
  sex!: string;
}
